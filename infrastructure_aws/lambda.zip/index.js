'use strict';

var lambda = require('lib/lambda');

exports.handler = lambda.handler;
